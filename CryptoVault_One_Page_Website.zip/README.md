# CryptoVault — One Page Crypto Investment Website

A responsive front-end demo built with plain HTML, CSS and JavaScript.

## Run in VS Code
1. Extract the ZIP.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.
4. No build step or Node.js is required.

## Files
- `index.html` — page structure and content
- `style.css` — responsive styling
- `script.js` — menu, modal, FAQ and demo-form interactions

## Important
This template is a front-end demonstration. It does not process real investments, deposits, withdrawals, accounts, or payments. Before using a crypto investment site commercially, add appropriate legal disclosures, privacy/terms pages, security controls, and any licensing/compliance required in the jurisdictions where you operate. Do not advertise guaranteed or risk-free investment returns.
