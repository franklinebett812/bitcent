const modal = document.getElementById("modal");
const closeBtn = document.getElementById("close");
const modalTitle = document.getElementById("modalTitle");
const formMsg = document.getElementById("formMsg");

document.querySelectorAll("[data-modal='login']").forEach(btn => {
  btn.addEventListener("click", () => {
    modalTitle.textContent = "Welcome back";
    modal.classList.add("show");
  });
});

document.querySelectorAll(".choose").forEach(btn => {
  btn.addEventListener("click", () => {
    modalTitle.textContent = `${btn.dataset.plan} plan`;
    formMsg.textContent = "";
    modal.classList.add("show");
  });
});

closeBtn.addEventListener("click", () => modal.classList.remove("show"));
modal.addEventListener("click", e => {
  if (e.target === modal) modal.classList.remove("show");
});

document.getElementById("demoForm").addEventListener("submit", e => {
  e.preventDefault();
  formMsg.textContent = "Demo only — no account or payment was created.";
});

document.querySelectorAll(".faq-item").forEach(item => {
  item.addEventListener("click", () => item.classList.toggle("open"));
});

const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");
menuBtn.addEventListener("click", () => {
  const open = navLinks.style.display === "flex";
  navLinks.style.display = open ? "" : "flex";
  if (!open) {
    navLinks.style.position = "absolute";
    navLinks.style.top = "76px";
    navLinks.style.left = "0";
    navLinks.style.right = "0";
    navLinks.style.padding = "20px 6%";
    navLinks.style.background = "#07111f";
    navLinks.style.flexDirection = "column";
  }
});
